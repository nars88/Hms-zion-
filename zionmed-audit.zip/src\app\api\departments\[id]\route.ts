import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

async function ensureDepartmentsTable() {
  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS departments (
      id TEXT PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      description TEXT,
      color TEXT,
      head_employee_id TEXT,
      hod_name TEXT,
      hod_tag TEXT,
      employee_ids JSONB,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `)
  await prisma.$executeRawUnsafe(`ALTER TABLE departments ADD COLUMN IF NOT EXISTS description TEXT`)
  await prisma.$executeRawUnsafe(`ALTER TABLE departments ADD COLUMN IF NOT EXISTS color TEXT`)
  await prisma.$executeRawUnsafe(`ALTER TABLE departments ADD COLUMN IF NOT EXISTS head_employee_id TEXT`)
  await prisma.$executeRawUnsafe(`ALTER TABLE departments ADD COLUMN IF NOT EXISTS hod_name TEXT`)
  await prisma.$executeRawUnsafe(`ALTER TABLE departments ADD COLUMN IF NOT EXISTS hod_tag TEXT`)
  await prisma.$executeRawUnsafe(`ALTER TABLE departments ADD COLUMN IF NOT EXISTS employee_ids JSONB`)
  await prisma.$executeRawUnsafe(`ALTER TABLE users ADD COLUMN IF NOT EXISTS department_id TEXT`)
}

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    await ensureDepartmentsTable()
    const body = await request.json().catch(() => ({}))
    const name = typeof body?.name === 'string' ? body.name.trim() : ''
    const description = typeof body?.description === 'string' ? body.description.trim() : ''
    const color = typeof body?.color === 'string' ? body.color.trim() : ''
    const headEmployeeId = typeof body?.headEmployeeId === 'string' ? body.headEmployeeId.trim() : ''
    const hodName = typeof body?.headOfDepartmentName === 'string' ? body.headOfDepartmentName.trim() : ''
    const hodTag = typeof body?.hodTag === 'string' ? body.hodTag.trim() : ''
    const assignedEmployeeIds = Array.isArray(body?.assignedEmployeeIds)
      ? body.assignedEmployeeIds.filter((x: unknown) => typeof x === 'string')
      : []

    if (!name) {
      return NextResponse.json({ error: 'Department name is required' }, { status: 400 })
    }

    const [updatedRows] = await prisma.$transaction(async (tx) => {
      const result = await tx.$queryRawUnsafe<Array<{ id: string }>>(
        `UPDATE departments
         SET name = $1,
             description = $2,
             color = $3,
             head_employee_id = $4,
             hod_name = $5,
             hod_tag = $6,
             employee_ids = $7::jsonb
         WHERE id = $8
         RETURNING id`,
        name,
        description || null,
        color || '#4f46e5',
        headEmployeeId || null,
        hodName || null,
        hodTag || null,
        JSON.stringify(assignedEmployeeIds),
        params.id
      )

      if (!result.length) return [null]

      await tx.$executeRawUnsafe(
        `UPDATE users
         SET department_id = NULL
         WHERE department_id = $1
           AND NOT (id = ANY($2::text[]))`,
        params.id,
        assignedEmployeeIds
      )

      if (assignedEmployeeIds.length > 0) {
        await tx.$executeRawUnsafe(
          `UPDATE users SET department_id = $1 WHERE id = ANY($2::text[])`,
          params.id,
          assignedEmployeeIds
        )
      }

      return [result]
    })

    if (!updatedRows?.length) {
      return NextResponse.json({ error: 'Department not found' }, { status: 404 })
    }

    return NextResponse.json({ success: true, id: updatedRows[0].id })
  } catch (error: any) {
    const msg = String(error?.message || '')
    if (msg.includes('duplicate key') || msg.includes('unique')) {
      return NextResponse.json({ error: 'Department name already exists' }, { status: 409 })
    }
    console.error('❌ Error updating department:', error)
    return NextResponse.json({ error: error?.message || 'Failed to update department' }, { status: 500 })
  }
}

export async function PUT(
  request: Request,
  context: { params: { id: string } }
) {
  return PATCH(request, context)
}

