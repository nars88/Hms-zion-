'use client'

import { useState, useEffect } from 'react'
import { UserPlus, Trash2, Edit2, Save, X, Loader2, Users } from 'lucide-react'
import { USER_ROLES, UserRole } from '@/contexts/AuthContext'

interface Employee {
  id: string
  name: string
  email: string
  role: UserRole
  phone?: string | null
}

const ROLE_OPTIONS: UserRole[] = [
  USER_ROLES.ADMIN,
  USER_ROLES.DOCTOR,
  USER_ROLES.RECEPTIONIST,
  USER_ROLES.PHARMACIST,
  USER_ROLES.ACCOUNTANT,
  USER_ROLES.SECURITY,
  USER_ROLES.LAB_TECH,
  USER_ROLES.RADIOLOGY_TECH,
  USER_ROLES.INTAKE_NURSE,
  USER_ROLES.ER_NURSE,
  USER_ROLES.SECRETARY,
]

// Helper to map role tag to UserRole
const mapTagToRole = (tag: string): UserRole | null => {
  const tagMap: Record<string, UserRole> = {
    'Admin': USER_ROLES.ADMIN,
    'Doctor': USER_ROLES.DOCTOR,
    'Nurse': USER_ROLES.PHARMACIST,
    'Receptionist': USER_ROLES.RECEPTIONIST,
    'Accountant': USER_ROLES.ACCOUNTANT,
    'Security': USER_ROLES.SECURITY,
    'Lab Tech': USER_ROLES.LAB_TECH,
    'Radiology Tech': USER_ROLES.RADIOLOGY_TECH,
    'Intake Nurse': USER_ROLES.INTAKE_NURSE,
    'ER Nurse': USER_ROLES.ER_NURSE,
    'Secretary': USER_ROLES.SECRETARY,
  }
  return tagMap[tag] || null
}

export default function EmployeeManagement() {
  const [employees, setEmployees] = useState<Employee[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isAdding, setIsAdding] = useState(false)
  const [showAddModal, setShowAddModal] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [newEmployee, setNewEmployee] = useState({
    name: '',
    phone: '',
    address: '',
    education: '',
    experience: '',
    email: '',
    password: '',
    role: USER_ROLES.DOCTOR as UserRole,
  })

  useEffect(() => {
    loadEmployees()
  }, [])

  const loadEmployees = async () => {
    try {
      setIsLoading(true)
      const res = await fetch('/api/employees')
      if (!res.ok) throw new Error('Failed to load employees')
      const data = await res.json()
      
      // Handle both response formats
      let employeesList: Employee[] = []
      if (Array.isArray(data)) {
        // Old format - array directly
        employeesList = data.map((emp: any) => ({
          id: emp.userId || emp.id,
          name: emp.name,
          email: emp.email,
          role: mapTagToRole(emp.role_tag || emp.role) || USER_ROLES.DOCTOR,
          phone: emp.phone || null,
        }))
      } else if (data.employees) {
        // New format - with employees property
        employeesList = data.employees.map((emp: any) => ({
          id: emp.id,
          name: emp.name,
          email: emp.email,
          role: emp.role || USER_ROLES.DOCTOR,
          phone: emp.phone || null,
        }))
      }
      
      setEmployees(employeesList)
    } catch (error: any) {
      console.error('Error loading employees:', error)
      alert('Failed to load employees: ' + error.message)
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddEmployee = async () => {
    if (!newEmployee.name || !newEmployee.email || !newEmployee.password || !newEmployee.role) {
      alert('Please fill all required fields (Name, Email, Password, and Role)')
      return
    }

    try {
      setIsAdding(true)
      const res = await fetch('/api/employees', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newEmployee.name,
          email: newEmployee.email,
          password: newEmployee.password,
          role: newEmployee.role,
          phone: newEmployee.phone || null,
          address: newEmployee.address || null,
          education: newEmployee.education || null,
          experience: newEmployee.experience ? parseInt(newEmployee.experience) : null,
        }),
      })

      if (!res.ok) {
        const error = await res.json()
        throw new Error(error.error || 'Failed to add employee')
      }

      await loadEmployees()
      setNewEmployee({
        name: '',
        phone: '',
        address: '',
        education: '',
        experience: '',
        email: '',
        password: '',
        role: USER_ROLES.DOCTOR,
      })
      setShowAddModal(false)
      alert('✅ Employee added successfully!')
    } catch (error: any) {
      console.error('Error adding employee:', error)
      alert('Failed to add employee: ' + error.message)
    } finally {
      setIsAdding(false)
    }
  }

  const handleDeleteEmployee = async (id: string, name: string) => {
    if (!confirm(`Are you sure you want to delete ${name}? This action cannot be undone.`)) {
      return
    }

    try {
      const res = await fetch(`/api/employees/${id}`, {
        method: 'DELETE',
      })

      if (!res.ok) {
        const error = await res.json()
        throw new Error(error.error || 'Failed to delete employee')
      }

      await loadEmployees()
      alert('✅ Employee deleted successfully!')
    } catch (error: any) {
      console.error('Error deleting employee:', error)
      alert('Failed to delete employee: ' + error.message)
    }
  }

  const handleUpdateRole = async (id: string, newRole: UserRole) => {
    try {
      const res = await fetch(`/api/employees/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: newRole }),
      })

      if (!res.ok) {
        const error = await res.json()
        throw new Error(error.error || 'Failed to update role')
      }

      await loadEmployees()
      setEditingId(null)
      alert('✅ Role updated successfully!')
    } catch (error: any) {
      console.error('Error updating role:', error)
      alert('Failed to update role: ' + error.message)
    }
  }

  const getRoleDisplayName = (role: UserRole): string => {
    const roleMap: Record<UserRole, string> = {
      [USER_ROLES.ADMIN]: 'Admin',
      [USER_ROLES.DOCTOR]: 'Doctor',
      [USER_ROLES.RECEPTIONIST]: 'Receptionist',
      [USER_ROLES.PHARMACIST]: 'Pharmacist',
      [USER_ROLES.ACCOUNTANT]: 'Accountant',
      [USER_ROLES.SECURITY]: 'Security',
      [USER_ROLES.LAB_TECH]: 'Lab Tech',
      [USER_ROLES.RADIOLOGY_TECH]: 'Radiology Tech',
      [USER_ROLES.INTAKE_NURSE]: 'Intake Nurse',
      [USER_ROLES.ER_NURSE]: 'ER Nurse',
      [USER_ROLES.SECRETARY]: 'Secretary',
    }
    return roleMap[role] || role
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="animate-spin text-cyan-400" size={32} />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header with Add Button - Always Visible */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex-1">
          <h2 className="text-2xl font-bold text-primary flex items-center gap-3">
            <Users size={28} className="text-cyan-400" />
            Employee Management
          </h2>
          <p className="text-sm text-secondary mt-1">
            Manage staff members, roles, and access permissions
          </p>
        </div>
        <div className="flex w-full flex-wrap items-center justify-start gap-2 sm:w-auto sm:justify-end">
          <button
            onClick={() => setShowAddModal(true)}
            className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-xl font-bold hover:from-cyan-600 hover:to-blue-600 transition-all flex items-center gap-2 shadow-lg hover:shadow-cyan-500/20 whitespace-nowrap flex-shrink-0"
          >
            <UserPlus size={20} />
            <span>Add New Employee</span>
          </button>
        </div>
      </div>

      {/* Employees Table */}
      <div className="glass rounded-xl border border-slate-800/50 overflow-hidden">
        <div className="p-6 border-b border-slate-800/50">
          <h3 className="text-lg font-semibold text-primary">
            All Employees ({employees.length})
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-900/50 border-b border-slate-800/50">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-secondary uppercase tracking-wider">
                  Name
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-secondary uppercase tracking-wider">
                  Email
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-secondary uppercase tracking-wider">
                  Role/Tag
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-secondary uppercase tracking-wider">
                  Phone
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-secondary uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {employees.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-secondary">
                    No employees found. Add your first employee above.
                  </td>
                </tr>
              ) : (
                employees.map((employee) => (
                  <tr key={employee.id} className="hover:bg-slate-900/30 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-primary">{employee.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-secondary">{employee.email}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {editingId === employee.id ? (
                        <select
                          value={employee.role}
                          onChange={(e) => handleUpdateRole(employee.id, e.target.value as UserRole)}
                          className="px-3 py-1.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-sm text-primary focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-500/50"
                          autoFocus
                        >
                          {ROLE_OPTIONS.map((role) => (
                            <option key={role} value={role}>
                              {getRoleDisplayName(role)}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <div className="flex items-center gap-2">
                          <span className="px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 rounded-lg text-sm font-medium text-cyan-400">
                            {getRoleDisplayName(employee.role)}
                          </span>
                          <button
                            onClick={() => setEditingId(employee.id)}
                            className="p-1 text-slate-400 hover:text-cyan-400 transition-colors"
                            title="Edit role"
                          >
                            <Edit2 size={14} />
                          </button>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-secondary">
                        {employee.phone || 'N/A'}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <div className="flex items-center justify-end gap-2">
                        {editingId === employee.id ? (
                          <>
                            <button
                              onClick={() => setEditingId(null)}
                              className="p-2 text-slate-400 hover:text-rose-400 transition-colors"
                              title="Cancel"
                            >
                              <X size={16} />
                            </button>
                          </>
                        ) : (
                          <button
                            onClick={() => handleDeleteEmployee(employee.id, employee.name)}
                            className="p-2 text-slate-400 hover:text-rose-400 transition-colors"
                            title="Delete employee"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Employee Modal - Full Staff Profile Form */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass rounded-2xl border border-slate-800/50 p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-primary flex items-center gap-2">
                <UserPlus size={24} className="text-cyan-400" />
                Add New Employee - Staff Profile
              </h3>
              <button
                onClick={() => {
                  setShowAddModal(false)
                  setNewEmployee({
                    name: '',
                    phone: '',
                    address: '',
                    education: '',
                    experience: '',
                    email: '',
                    password: '',
                    role: USER_ROLES.DOCTOR,
                  })
                }}
                className="p-2 text-slate-400 hover:text-rose-400 transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Personal Information Section */}
            <div className="mb-6">
              <h4 className="text-sm font-semibold text-cyan-400 mb-4 uppercase tracking-wider">
                Personal Information
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-secondary mb-2">
                    Full Name (الاسم الكامل) <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={newEmployee.name}
                    onChange={(e) => setNewEmployee({ ...newEmployee, name: e.target.value })}
                    placeholder="Enter full name"
                    className="w-full px-4 py-2 bg-slate-900/50 border border-slate-700/50 rounded-lg text-primary focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-500/50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary mb-2">
                    Phone Number (رقم الهاتف)
                  </label>
                  <input
                    type="tel"
                    value={newEmployee.phone}
                    onChange={(e) => setNewEmployee({ ...newEmployee, phone: e.target.value })}
                    placeholder="+964 750 123 4567"
                    className="w-full px-4 py-2 bg-slate-900/50 border border-slate-700/50 rounded-lg text-primary focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-500/50"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-secondary mb-2">
                    Address (العنوان السكني)
                  </label>
                  <input
                    type="text"
                    value={newEmployee.address}
                    onChange={(e) => setNewEmployee({ ...newEmployee, address: e.target.value })}
                    placeholder="Enter residential address"
                    className="w-full px-4 py-2 bg-slate-900/50 border border-slate-700/50 rounded-lg text-primary focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-500/50"
                  />
                </div>
              </div>
            </div>

            {/* Professional Information Section */}
            <div className="mb-6">
              <h4 className="text-sm font-semibold text-cyan-400 mb-4 uppercase tracking-wider">
                Professional Information
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-secondary mb-2">
                    Education/Degree (التحصيل الدراسي/الشهادة)
                  </label>
                  <input
                    type="text"
                    value={newEmployee.education}
                    onChange={(e) => setNewEmployee({ ...newEmployee, education: e.target.value })}
                    placeholder="e.g., MBBS, B.Sc. Nursing, B.Pharm"
                    className="w-full px-4 py-2 bg-slate-900/50 border border-slate-700/50 rounded-lg text-primary focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-500/50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary mb-2">
                    Years of Experience (سنوات الخبرة)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="50"
                    value={newEmployee.experience}
                    onChange={(e) => setNewEmployee({ ...newEmployee, experience: e.target.value })}
                    placeholder="e.g., 5"
                    className="w-full px-4 py-2 bg-slate-900/50 border border-slate-700/50 rounded-lg text-primary focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-500/50"
                  />
                </div>
              </div>
            </div>

            {/* Account Credentials Section */}
            <div className="mb-6">
              <h4 className="text-sm font-semibold text-cyan-400 mb-4 uppercase tracking-wider">
                Account Credentials
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-secondary mb-2">
                    Email <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="email"
                    value={newEmployee.email}
                    onChange={(e) => setNewEmployee({ ...newEmployee, email: e.target.value })}
                    placeholder="email@zion.com"
                    className="w-full px-4 py-2 bg-slate-900/50 border border-slate-700/50 rounded-lg text-primary focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-500/50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary mb-2">
                    Password <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="password"
                    value={newEmployee.password}
                    onChange={(e) => setNewEmployee({ ...newEmployee, password: e.target.value })}
                    placeholder="Temporary password"
                    className="w-full px-4 py-2 bg-slate-900/50 border border-slate-700/50 rounded-lg text-primary focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-500/50"
                  />
                </div>
              </div>
            </div>

            {/* Role Assignment Section - Final Step */}
            <div className="mb-6 pt-4 border-t border-slate-800/50">
              <h4 className="text-sm font-semibold text-cyan-400 mb-4 uppercase tracking-wider">
                Assign Role/Tag (The Final Step)
              </h4>
              <div className="max-w-md">
                <label className="block text-sm font-medium text-secondary mb-2">
                  Role/Tag <span className="text-rose-400">*</span>
                </label>
                <select
                  value={newEmployee.role}
                  onChange={(e) => setNewEmployee({ ...newEmployee, role: e.target.value as UserRole })}
                  className="w-full px-4 py-2 bg-slate-900/50 border border-slate-700/50 rounded-lg text-primary focus:outline-none focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-500/50"
                >
                  {ROLE_OPTIONS.map((role) => (
                    <option key={role} value={role}>
                      {getRoleDisplayName(role)}
                    </option>
                  ))}
                </select>
                <p className="text-xs text-slate-500 mt-2">
                  Select the appropriate role for this employee (Admin, Doctor, Lab, Pharmacy, Accountant, Security)
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800/50">
              <button
                onClick={() => {
                  setShowAddModal(false)
                  setNewEmployee({
                    name: '',
                    phone: '',
                    address: '',
                    education: '',
                    experience: '',
                    email: '',
                    password: '',
                    role: USER_ROLES.DOCTOR,
                  })
                }}
                className="px-6 py-2 bg-slate-800/50 text-secondary rounded-lg font-semibold hover:bg-slate-700/50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddEmployee}
                disabled={isAdding}
                className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg font-semibold hover:from-cyan-600 hover:to-blue-600 transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isAdding ? (
                  <>
                    <Loader2 className="animate-spin" size={18} />
                    <span>Adding...</span>
                  </>
                ) : (
                  <>
                    <Save size={18} />
                    <span>Add Employee</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  )
}

