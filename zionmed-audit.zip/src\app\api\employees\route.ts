import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { UserRole } from '@prisma/client'

const DEPT_ROLE_MAP: Record<string, string[]> = {
  laboratory: ['LAB_TECH'],
  radiology: ['RADIOLOGY_TECH'],
  sonar: ['RADIOLOGY_TECH'],
  pharmacy: ['PHARMACIST'],
  reception: ['RECEPTIONIST', 'RECEPTION', 'SECRETARY'],
  security: ['SECURITY'],
  accounting: ['ACCOUNTANT'],
  intake: ['INTAKE_NURSE', 'ER_NURSE'],
  emergency: ['ER_NURSE', 'DOCTOR'],
}

// GET /api/employees - Fetch all employees
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const departmentType = searchParams.get('departmentType')?.toLowerCase() ?? ''
    const roles = DEPT_ROLE_MAP[departmentType]

    const users = await prisma.user.findMany({
      where: roles ? { role: { in: roles as UserRole[] } } : { role: { not: UserRole.ADMIN } },
      select: { id: true, name: true, role: true },
      orderBy: { name: 'asc' },
    })

    const employees = users.map((u) => ({
      id: u.id,
      name: u.name,
      role: u.role,
      employeeTag: u.role
        .split('_')
        .map((w: string) => w[0] + w.slice(1).toLowerCase())
        .join(' '),
    }))

    return NextResponse.json({ employees })
  } catch (error: any) {
    console.error('❌ Error fetching employees:', error)
    return NextResponse.json(
      { error: error?.message || 'Failed to fetch employees' },
      { status: 500 }
    )
  }
}

// POST /api/employees - Create new employee
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, password, role, phone, address, education, experience } = body

    if (!name || !email || !password || !role) {
      return NextResponse.json(
        { error: 'Name, email, password, and role are required' },
        { status: 400 }
      )
    }

    // Check if email already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'Email already exists' },
        { status: 400 }
      )
    }

    // Validate role
    const validRoles = Object.values(UserRole)
    if (!validRoles.includes(role)) {
      return NextResponse.json(
        { error: 'Invalid role' },
        { status: 400 }
      )
    }

    // Create user with full profile data
    const user = await prisma.user.create({
      data: {
        name: name.trim(),
        email: email.toLowerCase().trim(),
        password: password, // TODO: Hash password with bcrypt in production
        role: role as UserRole,
        phone: phone?.trim() || null,
        address: address?.trim() || null,
        education: education?.trim() || null,
        experience: experience ? parseInt(experience.toString()) : null,
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        phone: true,
        address: true,
        education: true,
        experience: true,
      },
    })

    return NextResponse.json({
      success: true,
      employee: user,
    })
  } catch (error: any) {
    console.error('❌ Error creating employee:', error)
    return NextResponse.json(
      { error: error?.message || 'Failed to create employee' },
      { status: 500 }
    )
  }
}
