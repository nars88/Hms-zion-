CREATE TABLE IF NOT EXISTS departments (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  description TEXT,
  color TEXT,
  head_employee_id TEXT,
  hod_name TEXT,
  hod_tag TEXT,
  employee_ids JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE users ADD COLUMN IF NOT EXISTS department_id TEXT;

INSERT INTO departments (id, name, description, color) VALUES
  (gen_random_uuid()::text, 'Emergency', 'Critical and urgent patient care.', '#ef4444'),
  (gen_random_uuid()::text, 'Reception', 'Registration, booking, and front-desk workflow.', '#0ea5e9'),
  (gen_random_uuid()::text, 'Pharmacy', 'Medication dispensing and prescription handling.', '#10b981'),
  (gen_random_uuid()::text, 'Laboratory', 'Lab requests and diagnostic result processing.', '#8b5cf6'),
  (gen_random_uuid()::text, 'Radiology', 'Imaging workflows including X-ray and scans.', '#6366f1'),
  (gen_random_uuid()::text, 'Intake', 'Initial assessment and triage intake process.', '#f59e0b'),
  (gen_random_uuid()::text, 'Security', 'Access control and gatekeeping operations.', '#f97316'),
  (gen_random_uuid()::text, 'Accounting', 'Billing, payments, and financial operations.', '#14b8a6')
ON CONFLICT (name) DO NOTHING;
