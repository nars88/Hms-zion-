import { prisma } from '@/lib/prisma'
import { apiError, apiSuccess, apiUnauthorized, apiServerError } from '@/lib/apiResponse'
import { UserRole } from '@prisma/client'

// Test ER Doctor (from seed): doctor@zion.med / doc123 — role is DOCTOR, redirects to /emergency/doctor

// POST /api/auth/login
// Authenticates user with email and password, returns user data. Session is client-side (localStorage + cookies).
export async function POST(request: Request) {
  try {
    let body: { email?: string; password?: string }
    try {
      body = await request.json()
    } catch {
      return apiError('Invalid request body. Email and password are required.', 400)
    }
    const rawEmail = body?.email
    const password = body?.password

    if (rawEmail == null || rawEmail === '' || password == null || password === '') {
      return apiError('Email and password are required', 400)
    }

    const email = String(rawEmail).toLowerCase().trim()

    // [TAG: Pharmacist #1] Dev fallback — pharm@zion.com / 123456 → /pharmacy
    if (email === 'pharm@zion.com' && password === '123456') {
      return apiSuccess({
        user: {
          id: 'pharmacist-dev',
          name: 'Pharmacist (Test)',
          email: 'pharm@zion.com',
          role: 'PHARMACIST' as UserRole,
          phone: '+964 750 000 0005',
        },
      })
    }

    // [TAG: Pharmacist #2 — ZION Med] Dev fallback — pharmacy@zion.med / pharm123 → /pharmacy (صرف الطلبات)
    if (email === 'pharmacy@zion.med' && password === 'pharm123') {
      return apiSuccess({
        user: {
          id: 'pharmacist-zionmed',
          name: 'Pharmacy (ZION Med)',
          email: 'pharmacy@zion.med',
          role: 'PHARMACIST' as UserRole,
          phone: '+964 750 000 0005',
        },
      })
    }

    // [TAG: Lab Technician] lab@zion.com → /lab (LAB_TECH)
    if (email === 'lab@zion.com' && password === 'lab123') {
      return apiSuccess({
        user: {
          id: 'lab-tech-dev',
          name: 'Lab Technician',
          email: 'lab@zion.com',
          role: 'LAB_TECH' as UserRole,
          phone: '+964 750 000 0012',
        },
      })
    }
    // [TAG: Radiology Technician] radio@zion.com → /radiology (RADIOLOGY_TECH)
    if (email === 'radio@zion.com' && password === 'radio123') {
      return apiSuccess({
        user: {
          id: 'radiology-tech-dev',
          name: 'Radiology Technician',
          email: 'radio@zion.com',
          role: 'RADIOLOGY_TECH' as UserRole,
          phone: '+964 750 000 0013',
        },
      })
    }
    // Legacy: lab@zion.med still maps to LAB_TECH (redirect to /lab)
    if (email === 'lab@zion.med' && password === 'lab123') {
      return apiSuccess({
        user: {
          id: 'lab-tech-legacy',
          name: 'Lab Technician (Legacy)',
          email: 'lab@zion.med',
          role: 'LAB_TECH' as UserRole,
          phone: '+964 750 000 0012',
        },
      })
    }

    const user = await prisma.user.findUnique({
      where: { email },
      select: {
        id: true,
        email: true,
        password: true,
        name: true,
        role: true,
        phone: true,
      },
    })

    // Dev fallback: إذا المستخدم doctor@zion.med غير موجود في DB (لم يُنفَّذ السيد) نسمح بالدخول بمستخدم تجريبي
    const isERDoctorFallback = email === 'doctor@zion.med' && password === 'doc123'
    if (!user) {
      if (isERDoctorFallback) {
        return apiSuccess({
          user: {
            id: 'er-doctor-dev',
            name: 'ER Doctor (Test)',
            email: 'doctor@zion.med',
            role: 'DOCTOR' as UserRole,
            phone: '+964 750 000 0011',
          },
        })
      }
      return apiUnauthorized('Invalid email or password')
    }

    // TODO: In production use bcrypt.compare(); passwords are plain for dev/seed data
    const isPasswordValid = password === user.password
    if (!isPasswordValid) {
      if (isERDoctorFallback) {
        return apiSuccess({
          user: {
            id: user.id,
            name: user.name ?? 'ER Doctor',
            email: user.email,
            role: (typeof user.role === 'string' ? user.role : String(user.role)) as UserRole,
            phone: user.phone ?? undefined,
          },
        })
      }
      return apiUnauthorized('Invalid email or password')
    }

    const role = (typeof user.role === 'string' ? user.role : String(user.role)) as UserRole

    return apiSuccess({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role,
        phone: user.phone,
      },
    })
  } catch (e) {
    console.error('Login API error:', e)
    return apiServerError('Failed to authenticate. Please try again.')
  }
}

