'use client'

import EmployeeManagement from '@/components/admin/EmployeeManagement'

export default function SettingsPage() {
  return (
    <div className="min-h-full bg-slate-950">
      <main className="flex-1 overflow-y-auto p-8">
        <EmployeeManagement />
      </main>
    </div>
  )
}
